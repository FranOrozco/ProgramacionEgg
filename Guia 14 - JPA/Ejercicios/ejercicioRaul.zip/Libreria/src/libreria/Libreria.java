package libreria;

public class Libreria {

    public static void main(String[] args) {
       Menu menu = new Menu();
       menu.ingresarLibros();
    }

}
