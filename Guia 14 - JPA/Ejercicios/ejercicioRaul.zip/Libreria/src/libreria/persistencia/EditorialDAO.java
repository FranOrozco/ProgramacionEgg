package libreria.persistencia;

import libreria.entidades.Editorial;

public class EditorialDAO extends DAO<Editorial>{
    
    @Override
    public void guardar(Editorial editorial){
        super.guardar(editorial);
    }

   
}
