/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tienda.servicios;

import tienda.entidades.Producto;
import tienda.persistencia.ProductoDAO;

/**
 *
 * @author pablo
 */
public class ProductoServicios {

    private ProductoDAO pdao;

    public ProductoServicios() {
        this.pdao = new ProductoDAO();
    }

    public void ListarProductos() {
        try {
            System.out.println("CODIGO\tNOMBRE\tPRECIO\tCOD DE FCA");
            for (Producto aux : pdao.ListarProductos()) {
                System.out.println(aux.getCodigo() + "\t" + aux.getNombre() + " \t" + aux.getPrecio() + "\t"
                        + aux.getCodigoFabricante());
            }
        } catch (Exception e) {
            System.out.println("ERROR EN LISTAR PRODUCTOS" + e.getMessage());
        }

    }


    public void ListarNombreyPrecio() {
        try {
            System.out.println("NOMBRE\t\t\tPRECIO");
            for (Producto aux : pdao.NombreyPrecio()) {
                System.out.println(aux.getNombre() + " \t" + aux.getPrecio());
            }
        } catch (Exception e) {
            System.out.println("ERROR EN MOSTRAR NOMBRE Y PRECIO" + e.getMessage());
        }
    }

    public void PreciosEntre() {
        try {
            System.out.println("CODIGO\tNOMBRE\tPRECIO\tCOD DE FCA");
            for (Producto aux : pdao.PreciosEntre()) {
                System.out.println(aux.getCodigo() + "\t" + aux.getNombre() + " \t" + aux.getPrecio() + "\t"
                        + aux.getCodigoFabricante());
            }
        } catch (Exception e) {
            System.out.println("ERROR EN LISTAR PRODUCTOS entre los valores" + e.getMessage());
        }

    }

    public void ListarPortatiles() {
        try {
            System.out.println("CODIGO\tNOMBRE\tPRECIO\tCOD DE FCA");
            for (Producto aux : pdao.Portatiles()) {
                System.out.println(aux.getCodigo() + "\t" + aux.getNombre() + " \t" + aux.getPrecio() + "\t"
                        + aux.getCodigoFabricante());
            }
        } catch (Exception e) {
            System.out.println("ERROR EN LISTAR Portatiles" + e.getMessage());
        }

    }

    public void MostrarBarato() {
        try {
            System.out.println("NOMBRE\t\t\t\tPRECIO");
            for (Producto aux : pdao.masBarato()) {
                System.out.println(aux.getNombre() + " \t" + aux.getPrecio());
            }
        } catch (Exception e) {
            System.out.println("ERROR EN LISTAR Precio Barato" + e.getMessage());
        }

    }

    public void CrearProducto() {
        try {
            Producto p1 = new Producto(12, "Pen Drive", 5d, 9);
            pdao.guardaProducto(p1);
        } catch (Exception e) {
        }
    }

    public void modificarProducto(String codigo) {
        try {
            pdao.buscarProductoYModificarPorCodigo(codigo);
        } catch (Exception e) {
        }
    }
}
