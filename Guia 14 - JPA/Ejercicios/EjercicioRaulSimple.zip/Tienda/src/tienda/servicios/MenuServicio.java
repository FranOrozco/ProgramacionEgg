package tienda.servicios;

import java.util.Scanner;

/**
 * a) Lista el nombre de todos los productos que hay en la tabla producto. b)
 * Lista los nombres y los precios de todos los productos de la tabla producto.
 * c) Listar aquellos productos que su precio esté entre 120 y 202. d) Buscar y
 * listar todos los Portátiles de la tabla producto. e) Listar el nombre y el
 * precio del producto más barato. f) Ingresar un producto a la base de datos.
 * g) Ingresar un fabricante a la base de datos. h) Editar un producto con datos
 * a elección.
 *
 * @author Raul Gomez
 */
public class MenuServicio {

    private ProductoServicios ps;
    private FabricanteServicios fs;
    private Scanner leer;

    public MenuServicio() {
        this.ps = new ProductoServicios();
        this.fs = new FabricanteServicios();
        this.leer = new Scanner(System.in).useDelimiter("\n");
    }

    public void menuServicios() {
        boolean bucle = true;
        do {
            System.out.println("***************************Menú***************************");
            System.out.println("1.- Listar Productos\n"
                    + "2.- Listar Nombres y precios de los Productos\n"
                    + "3.- Listar Productos con precio entre 120 y 202\n"
                    + "4.- Buscar y listar Portatiles\n"
                    + "5.- Listar nombre y precio de producto mas barato\n"
                    + "6.- Ingresar nuevo producto\n"
                    + "7.- Ingresar nuevo fabricante\n"
                    + "8.- Editar un producto a elección\n"
                    + "9.- Salir");
            System.out.println("**********************************************************");
            System.out.print("Elija una opción: ");
            switch (leer.next()) {
                case "1":
                    try {
                        ps.ListarProductos();
                    } catch (Exception e) {
                    }
                    break;
                case "2":
                    try {
                        ps.ListarNombreyPrecio();
                    } catch (Exception e) {
                    }
                    break;
                case "3":
                    try {
                        ps.PreciosEntre();
                    } catch (Exception e) {
                    }
                    break;
                case "4":
                    try {
                        ps.ListarPortatiles();
                    } catch (Exception e) {
                    }
                    break;
                case "5":
                    try {
                        ps.MostrarBarato();
                    } catch (Exception e) {
                    }
                    break;
                case "6":
                    try {
                        ps.CrearProducto();
                        ps.ListarProductos();
                    } catch (Exception e) {
                    }
                    break;
                case "7":
                    try {
                        fs.CrearFabricante();
                        fs.ListarFabricantes();
                    } catch (Exception e) {
                    }
                    break;
                case "8":
                    try {
                        ps.ListarProductos();
                        System.out.println("Seleccione el Codigo del producto a modificar");
                        String codigo = leer.next();
                        ps.modificarProducto(codigo);
                    } catch (Exception e) {
                    }
                    break;
                case "9":
                    bucle = false;
                    System.out.println("Hasta luego... !!");
                    break;
            }

        } while (bucle);

    }
}
