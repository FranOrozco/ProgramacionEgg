/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tienda.servicios;

import tienda.entidades.Fabricante;
import tienda.persistencia.FabricanteDAO;

/**
 *
 * @author pablo
 */
public class FabricanteServicios {
    private FabricanteDAO fdao; 

    public FabricanteServicios() {
    this.fdao =new FabricanteDAO(); 
    }
    
     public void CrearFabricante (){
        try {
        Fabricante f1 = new Fabricante (0, "Nisuta");
        fdao.guardaFabricante(f1); 
        } catch (Exception e) {
    }
    
        
}
  public void ListarFabricantes (){
        try {
            System.out.println("CODIGO\tNOMBRE");
            for (Fabricante aux : fdao.ListaFabricantes()) {
                System.out.println(aux.getCodigo()+ "\t"+ aux.getNombre());
        }
        } catch (Exception e) {
            System.out.println("ERROR EN LISTAR FABRICANTES"+e.getMessage());
        }
}
}