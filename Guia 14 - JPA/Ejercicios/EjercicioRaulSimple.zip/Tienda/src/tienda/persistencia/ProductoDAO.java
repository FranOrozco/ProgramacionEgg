package tienda.persistencia;

import java.util.ArrayList;
import java.util.Scanner;
import tienda.entidades.Producto;

/**
 *
 * @author PABLO
 */
public class ProductoDAO extends DAO {

    private Scanner leer;

    public ProductoDAO() {
        this.leer = new Scanner(System.in).useDelimiter("\n");
    }

//a) Lista el nombre de todos los productos que hay en la tabla producto.
    public ArrayList<Producto> ListarProductos() throws Exception {

        try {
            String sql = "SELECT * FROM producto";
            consultarBase(sql);
            Producto producto = null;
            ArrayList<Producto> listaProductos = new ArrayList();
            while (resultado.next()) {
                producto = new Producto();
                producto.setCodigo(resultado.getInt(1));
                producto.setNombre(resultado.getString(2));
                producto.setPrecio(resultado.getDouble(3));
                producto.setCodigoFabricante(resultado.getInt(4));
                listaProductos.add(producto);
            }
            desconectarBase();
            return listaProductos;

        } catch (Exception e) {
            throw e;
        }
    }
//b) Lista los nombres y los precios de todos los productos de la tabla producto.

    public ArrayList<Producto> NombreyPrecio() throws Exception {

        try {
            String sql = "SELECT NOMBRE, PRECIO FROM producto";
            consultarBase(sql);
            Producto producto = null;
            ArrayList<Producto> listaNombrePrecio = new ArrayList();
            while (resultado.next()) {
                producto = new Producto();
                producto.setNombre(resultado.getString(1));
                producto.setPrecio(resultado.getDouble(2));
                listaNombrePrecio.add(producto);
            }
            desconectarBase();
            return listaNombrePrecio;

        } catch (Exception e) {
            throw e;
        }
    }

//c) Listar aquellos productos que su precio esté entre 120 y 202.
    public ArrayList<Producto> PreciosEntre() throws Exception {

        try {
            String sql = "SELECT * FROM producto WHERE precio between 120 and 202";
            consultarBase(sql);
            Producto producto = null;
            ArrayList<Producto> lista = new ArrayList();
            while (resultado.next()) {
                producto = new Producto();
                producto.setCodigo(resultado.getInt(1));
                producto.setNombre(resultado.getString(2));
                producto.setPrecio(resultado.getDouble(3));
                producto.setCodigoFabricante(resultado.getInt(4));
                lista.add(producto);
            }
            desconectarBase();
            return lista;

        } catch (Exception e) {
            throw e;
        }
    }

//d) Buscar y listar todos los Portátiles de la tabla producto.
    public ArrayList<Producto> Portatiles() throws Exception {

        try {
            String sql = "SELECT * FROM producto WHERE nombre LIKE '%portatil%';";
            consultarBase(sql);
            Producto producto = null;
            ArrayList<Producto> lista = new ArrayList();
            while (resultado.next()) {
                producto = new Producto();
                producto.setCodigo(resultado.getInt(1));
                producto.setNombre(resultado.getString(2));
                producto.setPrecio(resultado.getDouble(3));
                producto.setCodigoFabricante(resultado.getInt(4));
                lista.add(producto);
            }
            desconectarBase();
            return lista;

        } catch (Exception e) {
            throw e;
        }
    }

//e) Listar el nombre y el precio del producto más barato.
    public ArrayList<Producto> masBarato() throws Exception {

        try {
            String sql = "SELECT Nombre, precio FROM producto WHERE precio =(SELECT MIN(PRECIO) FROM producto); ";
            consultarBase(sql);
            Producto producto = null;
            ArrayList<Producto> lista = new ArrayList();
            while (resultado.next()) {
                producto = new Producto();
                producto.setNombre(resultado.getString(1));
                producto.setPrecio(resultado.getDouble(2));
                lista.add(producto);
            }
            desconectarBase();
            return lista;

        } catch (Exception e) {
            throw e;
        }
    }

//f) Ingresar un producto a la base de datos.
    public void guardaProducto(Producto producto) throws Exception {
        try {
            if (producto == null) {
                throw new Exception("Debe indicar producto");
            }
            String sql = "INSERT INTO producto (codigo, nombre, precio, codigo_fabricante)"
                    + "VALUES ( " + producto.getCodigo() + " , '" + producto.getNombre() + "' , '" + producto.getPrecio() + "' , '"
                    + producto.getCodigoFabricante() + "');";

            System.out.println(sql);
            insertarModificarEliminar(sql);
        } catch (Exception e) {
            throw e;
        } finally {
            desconectarBase();
        }
    }
    //h) Editar un producto con datos a elección.

    public void editarUnProducto(Producto producto) throws Exception {

        try {
            if (producto == null) {
                throw new Exception("Debe indicar el producto que desea modificar");
            }

            String sql = "UPDATE Producto SET "
                    + "nombre = '" + producto.getNombre() + "' , precio = '"
                    + producto.getPrecio() + "' , codigo_fabricante = '"
                    + producto.getCodigoFabricante()
                    + "' WHERE (codigo = '" + producto.getCodigo() + "');";

            System.out.println(sql);
            insertarModificarEliminar(sql);
        } catch (Exception e) {
            throw e;
        } finally {
            desconectarBase();
        }
    }

    public Producto buscarProductoYModificarPorCodigo(String codigo) throws Exception {
        try {

            String sql = "SELECT * FROM producto"
                    + " WHERE codigo = '" + codigo + "';";

            consultarBase(sql);

            Producto producto = null;
            producto = new Producto();
            System.out.println("Ingrese el nuevo nombre del producto: ");
            String prod = leer.next();
            System.out.println("Ingrese el nuevo precio del producto: ");
            double precio = leer.nextDouble();
            System.out.println("Ingrese el nuevo código de fabricante: ");
            int codFab = leer.nextInt();

            while (resultado.next()) {

                if (prod == null) {
                    producto.setNombre(resultado.getString(2));
                } else {
                    producto.setNombre(prod);
                }
                if (precio == 0) {
                    producto.setPrecio(resultado.getDouble(3));
                } else {
                    producto.setPrecio(precio);
                }
                if (codFab == 0) {
                    producto.setCodigoFabricante(resultado.getInt(4));
                } else {
                    producto.setCodigoFabricante(codFab);
                }
                sql = "UPDATE Producto SET "
                        + "nombre = '" + producto.getNombre() + "', precio = " + producto.getPrecio() + ", codigo_fabricante = " + producto.getCodigoFabricante() + " WHERE codigo = '" + codigo + "';";
                insertarModificarEliminar(sql);
            }
            desconectarBase();
            return producto;
        } catch (Exception e) {
            desconectarBase();
            throw e;
        }
    }

    public void eliminarPorCodigo(int codigo) throws Exception {
        try {
            conectarBase();
            String sql = "delete from producto where codigo = " + codigo + ";";
            insertarModificarEliminar(sql);
        } catch (Exception e) {
            throw e;
        }

    }
}
