
package tienda.persistencia;

import java.util.ArrayList;
import tienda.entidades.Fabricante;

/**
 *
 * @author pablo
 */
public class FabricanteDAO extends DAO{
    
    
      public ArrayList<Fabricante> ListaFabricantes() throws Exception {
    
        try {
            String sql ="SELECT * FROM fabricante";
            consultarBase(sql);
            Fabricante fabricante = null; 
            ArrayList <Fabricante> listaFabricantes= new ArrayList();
            while (resultado.next()){
                fabricante = new Fabricante();
                fabricante.setCodigo(resultado.getInt(1));
                fabricante.setNombre(resultado.getString(2));
                
                listaFabricantes.add(fabricante);
            }
            desconectarBase();
            return listaFabricantes; 
            
        } catch (Exception e) {
            throw e;
        }
    }
    
    
    //g) Ingresar un fabricante a la base de datos

    public void guardaFabricante(Fabricante fabricante) throws Exception {
        try {
            if (fabricante == null) {
                throw new Exception("Debe indicar un fabricante");
            }
            String sql = "INSERT INTO fabricante (codigo, nombre)"
                    + "VALUES ( " + fabricante.getCodigo()+ " , '" + fabricante.getNombre()+ "');";

            System.out.println(sql);
            insertarModificarEliminar(sql);
        } catch (Exception e) {
            throw e;
        } finally {
            desconectarBase();
        }
    }

}
