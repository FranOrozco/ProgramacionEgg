/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tienda;

import tienda.entidades.Producto;
import tienda.persistencia.ProductoDAO;
import tienda.servicios.MenuServicio;

/**
 *
 * @author pablo
 */
public class Tienda {

    public static void main(String[] args) throws Exception {

        MenuServicio ms = new MenuServicio();
        ms.menuServicios();
   
        }

    }
